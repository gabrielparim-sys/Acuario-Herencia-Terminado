package Acuario

fun crearPeces() {
    println("=== Crear peces y acciones ===")
    val t = Tiburon()
    val p = PezPayaso()
    println("Color Tiburón: ${t.color}")
    println("Color Pez Payaso: ${p.color}")
    t.comer()
    p.comer()
    println()
}

fun construirAcuario() {
    println("=== Construcción de acuarios ===")
    val acuario1 = Acuario()
    acuario1.imprimirTamano()

    val acuario2 = Acuario(ancho = 25)
    acuario2.imprimirTamano()

    val acuario3 = Acuario(alto = 35, largo = 110)
    acuario3.imprimirTamano()

    val acuario4 = Acuario(ancho = 20, alto = 31, largo = 100)
    acuario4.imprimirTamano()

    val acuario5 = Acuario(numeroDePeces = 29)
    acuario5.imprimirTamano()

    val acuario6 = Acuario(numeroDePeces = 29)
    acuario6.imprimirTamano()
    acuario6.volumen = 70   // usa el setter para recalcular alto
    acuario6.imprimirTamano()

    val acuario7 = Acuario(largo = 25, ancho = 25, alto = 40)
    acuario7.imprimirTamano()

    println("=== Comparación rectángulo vs cilindro (mismas dimensiones base) ===")
    val miAcuario = Acuario(ancho = 25, largo = 25, alto = 40)
    miAcuario.imprimirTamano()

    val miTorre = TanqueTorre(alto = 40, diametro = 25)
    miTorre.imprimirTamano()
}

fun main() {
    construirAcuario()
    crearPeces()
}
