package Acuario

import kotlin.math.PI

open class Acuario(
    open var largo: Int = 100,
    open var ancho: Int = 20,
    open var alto: Int = 31
) {
    init {
        println("Inicializando acuario")
    }

    // Propiedad calculada con getter y setter
    open var volumen: Int
        get() = ancho * alto * largo / 1000   // cm³ -> litros
        set(valor) {
            // recalcula la altura para conseguir el volumen pedido
            alto = (valor * 1000) / (ancho * largo)
            println("Nuevo volumen establecido: $volumen l")
        }

    open val forma = "rectangulo"

    // porcentaje de llenado por defecto (heredable)
    open val agua: Double
        get() = volumen * 0.9   // 90% del volumen lleno por defecto

    // constructor secundario por número de peces
    constructor(numeroDePeces: Int) : this() {
        val tanque = numeroDePeces * 2000 * 1.1  // cm³ necesarios (estimación)
        this.alto = (tanque / (largo * ancho)).toInt()
    }

    fun imprimirTamano() {
        println(forma)
        println("Ancho: $ancho cm  Largo: $largo cm  Alto: $alto cm")
        val vol = volumen
        val aguaL = agua
        val porcentaje = if (vol > 0) (aguaL / vol * 100.0) else 0.0
        println("Volumen: $vol l  Agua: ${"%.2f".format(aguaL)} l (${String.format("%.1f", porcentaje)}% lleno)")
        println()
    }
}

class TanqueTorre(
    override var alto: Int,
    var diametro: Int
) : Acuario(alto = alto, ancho = diametro, largo = diametro) {

    // volumen del cilindro: π * r^2 * h  (convertimos a litros)
    override var volumen: Int
        get() = ((ancho / 2.0) * (largo / 2.0) * alto / 1000.0 * PI).toInt()
        set(valor) {
            // recalcular alto a partir del volumen deseado usando la fórmula del cilindro
            alto = ((valor * 1000.0 / PI) / ((ancho / 2.0) * (largo / 2.0))).toInt()
        }

    // en torre dejamos el 80% de agua
    override val agua: Double
        get() = volumen * 0.8

    override val forma = "cilindro"
}
